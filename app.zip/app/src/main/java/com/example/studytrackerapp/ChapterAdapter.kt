package com.example.studytrackerapp

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChapterAdapter(
    private val chapters: MutableList<Chapter>,
    private val chapterActivity: ChapterActivity,
    private val bookName: String // Added bookName parameter
) : RecyclerView.Adapter<ChapterAdapter.ChapterViewHolder>() {

    inner class ChapterViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val chapterName: TextView = itemView.findViewById(R.id.chapter_name)
        val editButton: Button = itemView.findViewById(R.id.edit_button)
        val deleteButton: Button = itemView.findViewById(R.id.delete_button)
        val completionDate: TextView = itemView.findViewById(R.id.completion_date)
        val pagesInfo: TextView = itemView.findViewById(R.id.pages_info)
        val timesRevised: TextView = itemView.findViewById(R.id.times_revised)
        val completionLevel: TextView = itemView.findViewById(R.id.completion_level)
        val revisionDates: TextView = itemView.findViewById(R.id.revision_dates)

        init {
            // Set onClick listener for delete button
            deleteButton.setOnClickListener {
                val chapter = chapters[adapterPosition]
                val position = adapterPosition
                AlertDialog.Builder(itemView.context)
                    .setTitle("Delete Chapter")
                    .setMessage("Are you sure you want to delete ${chapter.name}?")
                    .setPositiveButton("Delete") { _, _ ->
                        chapters.removeAt(position)
                        chapterActivity.updateTotalPages() // Update total pages
                        notifyItemRemoved(position) // Notify adapter of item removal
                        chapterActivity.saveChapters(bookName) // Save changes with bookName
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }

            // Set onClick listener for edit button
            editButton.setOnClickListener {
                Log.d("ChapterAdapter", "Edit button clicked for chapter: ${chapters[adapterPosition].name}")
                val chapter = chapters[adapterPosition]
                showEditChapterDialog(chapter, adapterPosition)
            }

            // Set onClick listener for the chapter item to open the note page
            itemView.setOnClickListener {
                val chapter = chapters[adapterPosition]
                openNotePage(chapter)
            }
        }

        private fun showEditChapterDialog(chapter: Chapter, position: Int) {
            val dialogView = LayoutInflater.from(itemView.context).inflate(R.layout.dialog_edit_chapter, null)

            // Find views in the dialog
            val chapterNameEdit: EditText = dialogView.findViewById(R.id.chapter_name_edit_text)
            val startPageEdit: EditText = dialogView.findViewById(R.id.start_page_edit_text)
            val endPageEdit: EditText = dialogView.findViewById(R.id.end_page_edit_text)
            val completionLevelSpinner: Spinner = dialogView.findViewById(R.id.completion_level_spinner)
            val completionDateEdit: EditText = dialogView.findViewById(R.id.completion_date_edit_text)
            val revisionDateEdit: EditText = dialogView.findViewById(R.id.revision_date_edit_text)
            val addRevisionButton: Button = dialogView.findViewById(R.id.add_revision_button)

            // Set current values
            chapterNameEdit.setText(chapter.name)
            startPageEdit.setText(chapter.startPage.toString())
            endPageEdit.setText(chapter.endPage.toString())
            completionDateEdit.setText(chapter.completionDate)

            // Set up the ArrayAdapter for the Spinner
            val adapter = ArrayAdapter.createFromResource(
                itemView.context,
                R.array.completion_levels,
                android.R.layout.simple_spinner_item
            )
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            completionLevelSpinner.adapter = adapter

            // Set the spinner to the current completion level
            val completionLevelIndex = adapter.getPosition(chapter.completionLevel)
            completionLevelSpinner.setSelection(completionLevelIndex)

            // Create the dialog
            val dialog = AlertDialog.Builder(itemView.context)
                .setTitle("Edit Section")
                .setView(dialogView)
                .setPositiveButton("Save") { _, _ ->
                    // Get updated values
                    val updatedName = chapterNameEdit.text.toString()
                    val updatedStartPage = startPageEdit.text.toString().toIntOrNull() ?: chapter.startPage
                    val updatedEndPage = endPageEdit.text.toString().toIntOrNull() ?: chapter.endPage
                    val updatedLevel = completionLevelSpinner.selectedItem.toString()
                    val updatedCompletionDate = completionDateEdit.text.toString()

                    // Update chapter details
                    chapter.name = updatedName
                    chapter.startPage = updatedStartPage
                    chapter.endPage = updatedEndPage
                    chapter.completionLevel = updatedLevel
                    chapter.completionDate = updatedCompletionDate

                    // Notify the adapter of the changed data
                    notifyItemChanged(position)
                    chapterActivity.saveChapters(bookName) // Save changes with bookName
                }
                .setNegativeButton("Cancel", null)
                .create()

            // Add revision date functionality
            addRevisionButton.setOnClickListener {
                val revisionDate = revisionDateEdit.text.toString()
                if (revisionDate.isNotEmpty()) {
                    chapter.revisionDates.add(revisionDate) // Add revision date

                    // Notify the adapter that the item has changed
                    notifyItemChanged(position)

                    // Optionally clear the input
                    revisionDateEdit.text.clear()
                }
            }

            dialog.show()
        }

        private fun openNotePage(chapter: Chapter) {
            // Create an intent to start com.example.studytrackerapp.NotesActivity
            val intent = Intent(itemView.context, NotesActivity::class.java).apply {
                putExtra("chapterId", chapter.name) // Assuming Chapter has an id property
                putExtra("bookName", bookName) // Pass the bookName to the intent
            }
            itemView.context.startActivity(intent) // Start the com.example.studytrackerapp.NotesActivity
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChapterViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.chapter_item, parent, false)
        return ChapterViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChapterViewHolder, position: Int) {
        val chapter = chapters[position]
        holder.chapterName.text = chapter.name
        holder.completionDate.text = "Date: ${chapter.completionDate}"
        holder.pagesInfo.text = "Pages: ${chapter.startPage} - ${chapter.endPage}"
        holder.timesRevised.text = "Revisions: ${chapter.revisionDates.size}" // Display number of revisions

        // Display the list of revision dates
        if (chapter.revisionDates.isNotEmpty()) {
            holder.revisionDates.text = "Revision Dates: (" + chapter.revisionDates.joinToString("") + ")"
        } else {
            holder.revisionDates.text = "Revision Dates: N/A"
        }

        holder.completionLevel.text = "Completion: ${chapter.completionLevel}" // Display completion level

        holder.chapterName.setTextColor(Color.BLACK)
        holder.completionDate.setTextColor(Color.BLACK)
        holder.pagesInfo.setTextColor(Color.BLACK)
        holder.timesRevised.setTextColor(Color.BLACK)
        holder.completionLevel.setTextColor(Color.BLACK)
        holder.revisionDates.setTextColor(Color.BLACK) // Set revision dates text color

        // Set background color based on completion level
        when (chapter.completionLevel) {
            "Incomplete" -> {
                holder.itemView.setBackgroundColor(Color.parseColor("#cfcfc4")) // Default color
                setTypefaceBold(holder)
            }
            "Read" -> {
                holder.itemView.setBackgroundColor(Color.parseColor("#A3C6EA")) // Light blue
                setTypefaceBold(holder)
            }
            "Revised" -> {
                holder.itemView.setBackgroundColor(Color.parseColor("#A8DAB3")) // Light green
                setTypefaceBold(holder)
            }
        }
    }

    private fun setTypefaceBold(holder: ChapterViewHolder) {
        holder.chapterName.setTypeface(holder.chapterName.typeface, android.graphics.Typeface.BOLD)
        holder.completionDate.setTypeface(holder.completionDate.typeface, android.graphics.Typeface.BOLD)
        holder.pagesInfo.setTypeface(holder.pagesInfo.typeface, android.graphics.Typeface.BOLD)
        holder.timesRevised.setTypeface(holder.timesRevised.typeface, android.graphics.Typeface.BOLD)
        holder.completionLevel.setTypeface(holder.completionLevel.typeface, android.graphics.Typeface.BOLD)
        holder.revisionDates.setTypeface(holder.revisionDates.typeface, android.graphics.Typeface.BOLD)
    }

    override fun getItemCount() = chapters.size
}
