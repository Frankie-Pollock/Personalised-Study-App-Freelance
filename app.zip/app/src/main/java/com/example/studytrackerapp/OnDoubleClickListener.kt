package com.example.studytrackerapp

import android.view.MotionEvent
import android.view.View

abstract class OnDoubleClickListener : View.OnTouchListener {
    private var lastClickTime: Long = 0
    private val DOUBLE_CLICK_TIME_DELTA: Long = 300 // milliseconds

    override fun onTouch(view: View?, event: MotionEvent?): Boolean {
        if (event?.action == MotionEvent.ACTION_UP) {
            val clickTime = System.currentTimeMillis()
            val clickDelta = clickTime - lastClickTime

            if (clickDelta < DOUBLE_CLICK_TIME_DELTA && clickDelta > 0) {
                onDoubleClick()
                return true
            }
            lastClickTime = clickTime
        }
        return false
    }

    abstract fun onDoubleClick()
}
