package com.example.studytrackerapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class FirstPageActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first) // Make sure this matches the layout file name

        // Initialize views and set click listeners
        val book1TextView: View = findViewById(R.id.book1_text_view)
        val book2TextView: View = findViewById(R.id.book2_text_view)
        val book3TextView: View = findViewById(R.id.book3_text_view)

        // Set click listeners for opening SectionActivity with book name
        book1TextView.setOnClickListener {
            openSectionActivity("book1")
        }

        book2TextView.setOnClickListener {
            openSectionActivity("book2")
        }

        book3TextView.setOnClickListener {
            openSectionActivity("book3")
        }
    }

    private fun openSectionActivity(bookName: String) {
        val intent = Intent(this, SectionActivity::class.java)
        intent.putExtra("book_name", bookName) // Pass the book name to the SectionActivity
        startActivity(intent)
    }
}
