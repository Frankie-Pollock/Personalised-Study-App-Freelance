package com.example.studytrackerapp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class SectionActivity : AppCompatActivity() {
    private lateinit var sectionsRecyclerView: RecyclerView
    private lateinit var sectionsAdapter: SectionsAdapter
    private val sectionsList = mutableListOf<Section>()
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var gson: Gson
    lateinit var bookName: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Get the book name from the intent
        bookName = intent.getStringExtra("book_name") ?: ""

        // Initialize shared preferences and RecyclerView
        sharedPreferences = getSharedPreferences("study_tracker", MODE_PRIVATE)
        gson = Gson()
        sectionsRecyclerView = findViewById(R.id.sections_recycler_view)
        sectionsRecyclerView.layoutManager = LinearLayoutManager(this)
        sectionsAdapter = SectionsAdapter(sectionsList, this)
        sectionsRecyclerView.adapter = sectionsAdapter

        loadSections(bookName)

        val addSectionButton: FloatingActionButton = findViewById(R.id.add_section_button)
        addSectionButton.setOnClickListener {
            showAddSectionDialog(bookName)
        }

        sectionsAdapter.setOnItemClickListener(object : SectionsAdapter.OnItemClickListener {
            override fun onItemClick(section: Section) {}

            override fun onItemDoubleClick(section: Section) {
                val intent = Intent(this@SectionActivity, ChapterActivity::class.java)
                intent.putExtra("section_name", section.name)
                intent.putExtra("book_name", bookName)
                startActivity(intent)
            }
        })

        // Attach ItemTouchHelper for drag-and-drop
        val itemTouchHelper = ItemTouchHelper(SectionItemTouchHelper(sectionsAdapter))
        itemTouchHelper.attachToRecyclerView(sectionsRecyclerView)
    }


    private fun showAddSectionDialog(bookName: String) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_section, null)
        val sectionNameEditText: EditText = dialogView.findViewById(R.id.section_name_edit_text)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Add Section")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val sectionName = sectionNameEditText.text.toString()
                if (sectionName.isNotEmpty()) {
                    // Create a new Section using the book name and the new section name
                    val newSection = Section(bookName = bookName, name = sectionName) // Pass both parameters
                    sectionsList.add(newSection)
                    sectionsAdapter.notifyItemInserted(sectionsList.size - 1)

                    // Save sections to SharedPreferences
                    saveSections(bookName)
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }

    private fun loadSections(bookName: String) {
        // Get the sections associated with the specific book name from SharedPreferences
        val json = sharedPreferences.getString("sections_$bookName", null)
        val type = object : TypeToken<List<Section>>() {}.type
        if (json != null) {
            val sections: List<Section> = gson.fromJson(json, type)
            sectionsList.clear()
            sectionsList.addAll(sections)
        }
        sectionsAdapter.notifyDataSetChanged() // Notify adapter to refresh the view
    }

    fun saveSections(bookName: String) {
        val editor = sharedPreferences.edit()
        val json = gson.toJson(sectionsList)
        editor.putString("sections_$bookName", json) // Save sections under the specific book name
        editor.apply()
    }

    // Override onCreateOptionsMenu to inflate the menu
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    // Handle menu item clicks
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.delete_section -> {
                // Handle delete section confirmation dialog
                showDeleteConfirmationDialog()
                true
            }
            R.id.edit_section -> {
                // Handle edit section dialog
                showEditSectionDialog(sectionsAdapter.getSelectedSection())
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showDeleteConfirmationDialog() {
        val selectedSection = sectionsAdapter.getSelectedSection() // Get selected section from adapter
        if (selectedSection != null) {
            val dialog = AlertDialog.Builder(this)
                .setTitle("Delete Section")
                .setMessage("Are you sure you want to delete '${selectedSection.name}'?")
                .setPositiveButton("Yes") { _, _ ->
                    sectionsList.remove(selectedSection)
                    sectionsAdapter.notifyDataSetChanged() // Notify adapter to refresh the view
                    saveSections(bookName) // Save updated sections list
                }
                .setNegativeButton("No", null)
                .create()

            dialog.show()
        }
    }

    private fun showEditSectionDialog(selectedSection: Section?) {
        if (selectedSection == null) return

        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_section, null)
        val editSectionNameEditText: EditText = dialogView.findViewById(R.id.chapter_name_edit_text)
        editSectionNameEditText.setText(selectedSection.name) // Set the current name in the EditText

        val dialog = AlertDialog.Builder(this)
            .setTitle("Edit Section")
            .setView(dialogView)
            .setPositiveButton("Edit") { _, _ ->
                val updatedName = editSectionNameEditText.text.toString()
                if (updatedName.isNotEmpty()) {
                    // Create a new instance with the updated name
                    val updatedSection = selectedSection.copy(name = updatedName)
                    val index = sectionsList.indexOf(selectedSection)
                    if (index != -1) {
                        sectionsList[index] = updatedSection // Replace the old section
                        sectionsAdapter.notifyItemChanged(index) // Notify adapter of the change
                        saveSections(bookName) // Save updated sections list
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }
}
