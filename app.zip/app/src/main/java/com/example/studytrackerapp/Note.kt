// Note.kt
package com.example.studytrackerapp

data class Note(
    val chapterName: String,
    var title: String = "",
    var content: String = ""
)