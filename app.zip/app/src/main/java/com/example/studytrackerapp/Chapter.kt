package com.example.studytrackerapp

data class Chapter(
    var name: String,
    var startPage: Int,
    var endPage: Int,
    var completionLevel: String,
    var completionDate: String = "N/A", // Default to "N/A" if not set
    var revisionDates: MutableList<String> = mutableListOf(), // List of revision dates

)
