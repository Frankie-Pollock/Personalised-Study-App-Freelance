package com.example.studytrackerapp

data class Section(
    val bookName: String, // Use book name instead of ID
    val name: String,
)