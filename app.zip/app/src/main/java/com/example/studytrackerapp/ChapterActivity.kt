package com.example.studytrackerapp

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ChapterActivity : AppCompatActivity() {

    private lateinit var chapterRecyclerView: RecyclerView
    private lateinit var chapterAdapter: ChapterAdapter
    private val chapterList = mutableListOf<Chapter>()
    private var totalNumOfPages = 0 // Track the total number of pages across all chapters
    private lateinit var sectionName: String
    private lateinit var bookName: String // Declare a variable for book name

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_section)

        // Retrieve the section name from the intent
        sectionName = intent.getStringExtra("section_name") ?: ""
        bookName = intent.getStringExtra("book_name") ?: "" // Get bookName

        // Set up the section title and RecyclerView
        val sectionTitle: TextView = findViewById(R.id.section_title)
        chapterRecyclerView = findViewById(R.id.recycler_view)
        chapterRecyclerView.layoutManager = LinearLayoutManager(this)
        chapterAdapter = ChapterAdapter(chapterList, this, bookName)
        chapterRecyclerView.adapter = chapterAdapter

        // Load existing chapters from SharedPreferences
        loadChapters(bookName)

        // Initialize the section title with total pages
        sectionTitle.text = "This Section covers $totalNumOfPages pages"

        // Button to add a new chapter
        val addChapterButton: Button = findViewById(R.id.add_chapter_button)
        addChapterButton.setOnClickListener {
            showAddChapterDialog(bookName)
        }
    }

    private fun showAddChapterDialog(bookName: String) {
        // Inflate the dialog layout
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_chapter, null)

        // Get references to input fields
        val chapterNameEditText: EditText = dialogView.findViewById(R.id.chapter_name_edit_text)
        val dateEditText: EditText = dialogView.findViewById(R.id.date_edit_text) // Reference to date EditText
        val startPageEditText: EditText = dialogView.findViewById(R.id.start_page_edit_text)
        val endPageEditText: EditText = dialogView.findViewById(R.id.end_page_edit_text)

        // Get reference to the completion level spinner
        val completionLevelSpinner: Spinner = dialogView.findViewById(R.id.completion_level_spinner)

        // Create the dialog
        val dialog = AlertDialog.Builder(this)
            .setTitle("Add Chapter")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val chapterName = chapterNameEditText.text.toString()
                val startPage = startPageEditText.text.toString()
                val endPage = endPageEditText.text.toString()

                // Fetch the selected completion level from the spinner
                val completionLevel = completionLevelSpinner.selectedItem.toString()

                // Get the date or set to "N/A" if empty
                val completionDate = dateEditText.text.toString().ifEmpty { "N/A" }

                // Validate input and create a new chapter
                if (chapterName.isNotEmpty() && startPage.isNotEmpty() && endPage.isNotEmpty()) {
                    val newChapter = Chapter(chapterName, startPage.toInt(), endPage.toInt(), completionLevel, completionDate)
                    chapterList.add(newChapter)
                    totalNumOfPages += (endPage.toInt() - startPage.toInt() + 1) // Update total pages
                    chapterAdapter.notifyItemInserted(chapterList.size - 1) // Notify adapter

                    // Save updated chapters to SharedPreferences
                    saveChapters(bookName) // Pass bookName here

                    // Update the section title with the new total pages
                    val sectionTitle: TextView = findViewById(R.id.section_title)
                    sectionTitle.text = "This Section covers $totalNumOfPages pages"
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }


    internal fun saveChapters(bookName: String) {
        // Save chapters list to SharedPreferences
        val sharedPreferences: SharedPreferences = getSharedPreferences("study_tracker", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()

        // Create a key that includes both section and book name
        val json = gson.toJson(chapterList)
        editor.putString("${bookName}_${sectionName}_chapters", json)
        editor.apply() // Apply changes
    }

    private fun loadChapters(bookName: String) {
        // Load chapters from SharedPreferences
        val sharedPreferences: SharedPreferences = getSharedPreferences("study_tracker", MODE_PRIVATE)
        val gson = Gson()

        // Create a key that includes both section and book name
        val json = sharedPreferences.getString("${bookName}_${sectionName}_chapters", null)
        val type = object : TypeToken<List<Chapter>>() {}.type

        chapterList.clear() // Clear the current list before loading
        if (json != null) {
            val chapters: List<Chapter> = gson.fromJson(json, type)
            chapterList.addAll(chapters) // Add loaded chapters to the list
        }
        totalNumOfPages = chapterList.sumOf { it.endPage - it.startPage + 1 } // Update total pages
        chapterAdapter.notifyDataSetChanged() // Refresh the RecyclerView
    }



    // Optional: This method is called when chapters are updated
    fun updateTotalPages() {
        totalNumOfPages = chapterList.sumOf { it.endPage - it.startPage + 1 }
        val sectionTitle: TextView = findViewById(R.id.section_title)
        sectionTitle.text = "This Section covers $totalNumOfPages pages"
    }
}