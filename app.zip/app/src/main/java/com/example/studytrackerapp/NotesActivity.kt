package com.example.studytrackerapp

import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class NotesActivity : AppCompatActivity(), NoteAdapter.OnNoteClickListener {

    private lateinit var notesRecyclerView: RecyclerView
    private lateinit var noteAdapter: NoteAdapter
    private val notesList = mutableListOf<Note>()
    private lateinit var chapterId: String
    private lateinit var noteContentEditText: EditText
    private var selectedNote: Note? = null
    private var selectedNotePosition: Int = -1 // Track the selected note's position
    private lateinit var bookName: String // Variable to store bookName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notes)

        chapterId = intent.getStringExtra("chapterId") ?: return
        bookName = intent.getStringExtra("bookName") ?: "Unknown Book" // Default to "Unknown Book" if bookName isn't passed

        Log.d("com.example.studytrackerapp.NotesActivity", "Chapter ID received: $chapterId, Book Name received: $bookName")

        notesRecyclerView = findViewById(R.id.notes_recycler_view)
        noteContentEditText = findViewById(R.id.note_content_edit_text)

        notesRecyclerView.layoutManager = LinearLayoutManager(this)
        noteAdapter = NoteAdapter(notesList, this)
        notesRecyclerView.adapter = noteAdapter

        loadNotesForChapterAndBook(chapterId, bookName) // Updated to load notes based on chapterId and bookName

        // Initially hide the EditText
        noteContentEditText.visibility = View.GONE

        // Add note button
        val addNoteButton: Button = findViewById(R.id.add_note_button)
        addNoteButton.setOnClickListener {
            showAddNoteDialog()
        }

        // Add TextWatcher for live updates as the user types
        noteContentEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // No action needed here
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                selectedNote?.let {
                    it.content = s.toString() // Update the content in the selected note
                    if (selectedNotePosition >= 0) {
                        noteAdapter.updateNote(selectedNotePosition, it) // Update the note in the adapter
                    }
                    saveNotes() // Save notes whenever changes are made
                }
            }

            override fun afterTextChanged(s: Editable?) {
                // No action needed here
            }
        })

        // Set a touch listener to hide EditText when tapping outside
        notesRecyclerView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val x = event.x.toInt()
                val y = event.y.toInt()
                if (x < notesRecyclerView.left || x > notesRecyclerView.right || y < notesRecyclerView.top || y > notesRecyclerView.bottom) {
                    hideEditText() // Hide EditText when tapping outside
                }
            }
            false
        }

        // Set editor action listener to handle "Close" action
        noteContentEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_GO) {
                hideEditText() // Hide the EditText on "Close" or "Done"
                true // Indicate that we handled the action
            } else {
                false // Indicate that we did not handle the action
            }
        }
    }

    // Handle note click from the adapter
    override fun onNoteClick(note: Note) {
        selectedNote = note
        selectedNotePosition = notesList.indexOf(note) // Get the position of the clicked note
        noteContentEditText.setText(note.content) // Populate the EditText with the note's content
        noteContentEditText.visibility = View.VISIBLE // Show the EditText
        noteContentEditText.requestFocus() // Request focus for the EditText
    }

    private fun showAddNoteDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_note, null)
        val titleEditText: EditText = dialogView.findViewById(R.id.note_title_edit_text)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Add Note")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val title = titleEditText.text.toString()
                if (title.isNotEmpty()) {
                    val newNote = Note(chapterId, title)
                    notesList.add(newNote)
                    noteAdapter.notifyItemInserted(notesList.size - 1)
                    saveNotes()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }

    // Updated method to load notes based on chapterId and bookName
    private fun loadNotesForChapterAndBook(chapterId: String, bookName: String) {
        val sharedPreferences: SharedPreferences = getSharedPreferences("study_tracker", MODE_PRIVATE)
        val gson = Gson()
        val json = sharedPreferences.getString("notes_for_${bookName}_$chapterId", null) // Include bookName in the key
        val type = object : TypeToken<List<Note>>() {}.type

        notesList.clear()
        if (json != null) {
            val notes: List<Note> = gson.fromJson(json, type)
            notesList.addAll(notes)
        }
        noteAdapter.notifyDataSetChanged()
    }

    // Updated method to save notes based on chapterId and bookName
    private fun saveNotes() {
        val sharedPreferences: SharedPreferences = getSharedPreferences("study_tracker", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()
        val json = gson.toJson(notesList)
        editor.putString("notes_for_${bookName}_$chapterId", json) // Include bookName in the key
        editor.apply()
    }

    private fun hideEditText() {
        noteContentEditText.visibility = View.GONE // Hide the EditText
        selectedNote = null // Reset the selected note
        selectedNotePosition = -1 // Reset the position
        noteContentEditText.setText("") // Clear the EditText content
    }
}
