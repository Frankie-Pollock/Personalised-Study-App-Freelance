package com.example.studytrackerapp

data class Book(
    val title: String,
    val sections: MutableList<Section>
)