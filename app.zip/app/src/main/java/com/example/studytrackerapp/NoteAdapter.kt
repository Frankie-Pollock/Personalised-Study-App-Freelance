package com.example.studytrackerapp

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// Adapter class for displaying notes in a RecyclerView
class NoteAdapter(
    private var notes: MutableList<Note>, // List of notes to display
    private val listener: OnNoteClickListener // Listener for item click events
) : RecyclerView.Adapter<NoteAdapter.NoteViewHolder>() {

    // Interface for handling note click events
    interface OnNoteClickListener {
        fun onNoteClick(note: Note) // Method to be implemented for note clicks
    }

    // ViewHolder class to hold the views for each note item
    class NoteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val noteTitle: TextView = itemView.findViewById(R.id.note_title)
        val noteContent: TextView = itemView.findViewById(R.id.note_content) // Add note_content TextView
        val deleteButton: ImageButton = itemView.findViewById(R.id.note_delete_button) // Change to ImageButton
    }

    // Inflate the layout for each note item
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.note_item, parent, false)
        return NoteViewHolder(view)
    }

    // Bind data to the views for each note item
    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        val note = notes[position]
        holder.noteTitle.text = note.title // Set the title of the note
        holder.noteContent.text = note.content // Set the content of the note

        // Handle note click
        holder.itemView.setOnClickListener {
            listener.onNoteClick(note) // Notify listener of the note click
        }

        // Handle delete button click
        holder.deleteButton.setOnClickListener {
            deleteNoteAt(position) // Delete note at the specified position
        }
    }

    // Return the total number of notes
    override fun getItemCount(): Int {
        return notes.size
    }

    // Delete a note at the specified position
    fun deleteNoteAt(position: Int) {
        if (position in notes.indices) {
            notes.removeAt(position) // Remove the note from the list
            notifyItemRemoved(position) // Notify that the item has been removed
        }
    }

    // Update a note at the specified position
    fun updateNote(position: Int, updatedNote: Note) {
        if (position in notes.indices) { // Check if the position is valid
            notes[position] = updatedNote // Update the note at the specified position
            notifyItemChanged(position) // Notify that the item has changed
        } else {
            Log.e("NoteAdapter", "Invalid position: $position") // Log an error for an invalid position
        }
    }
}
