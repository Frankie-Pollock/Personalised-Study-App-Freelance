package com.example.studytrackerapp

import android.content.Context
import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import java.util.Collections

class SectionsAdapter(private val sections: MutableList<Section>, private val context: Context) : RecyclerView.Adapter<SectionsAdapter.SectionViewHolder>() {

    private var selectedSection: Section? = null
    private val highlightedColor = 0xFF404040.toInt() // Highlighted color
    private val normalColor = 0xFFADD8E6.toInt() // Normal color
    private lateinit var itemTouchHelper: ItemTouchHelper // Declare ItemTouchHelper

    private var itemClickListener: OnItemClickListener? = null

    interface OnItemClickListener {
        fun onItemClick(section: Section)
        fun onItemDoubleClick(section: Section)
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        itemClickListener = listener
    }
    fun onItemMove(fromPosition: Int, toPosition: Int) {
        Collections.swap(sections, fromPosition, toPosition)
        notifyItemMoved(fromPosition, toPosition)
        // Save the updated sections list to SharedPreferences
        (context as SectionActivity).saveSections(context.bookName)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SectionViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_section, parent, false)
        return SectionViewHolder(view)
    }

    override fun onBindViewHolder(holder: SectionViewHolder, position: Int) {
        val section = sections[position]
        holder.bind(section)

        // Set the background color based on selection
        holder.itemView.setBackgroundColor(if (section == selectedSection) highlightedColor else normalColor)

        // Click listener for highlighting
        holder.itemView.setOnClickListener {
            selectSection(section)
            itemClickListener?.onItemClick(section)
        }

        // Double-click listener for opening the section activity
        holder.itemView.setOnTouchListener(object : OnDoubleClickListener() {
            override fun onDoubleClick() {
                itemClickListener?.onItemDoubleClick(section)
            }
        })
    }

    override fun getItemCount(): Int = sections.size

    private fun selectSection(section: Section) {
        // Deselect the previously selected section
        selectedSection?.let {
            notifyItemChanged(sections.indexOf(it)) // Update the previous section's background
        }

        // Select the new section
        selectedSection = section
        notifyItemChanged(sections.indexOf(section)) // Update the new section's background
    }

    fun getSelectedSection(): Section? {
        return selectedSection
    }

    // Method to swap sections
    fun swapSections(fromPosition: Int, toPosition: Int) {
        val sectionToMove = sections[fromPosition]
        sections.removeAt(fromPosition)
        sections.add(toPosition, sectionToMove)
        notifyItemMoved(fromPosition, toPosition)
        saveSectionsOrder() // Save the new order
    }

    // Set up the ItemTouchHelper for drag and drop
    fun attachDragAndDrop(recyclerView: RecyclerView) {
        itemTouchHelper = ItemTouchHelper(object : ItemTouchHelper.Callback() {
            override fun getMovementFlags(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder): Int {
                val dragFlags = ItemTouchHelper.UP or ItemTouchHelper.DOWN
                return makeMovementFlags(dragFlags, 0)
            }

            override fun onMove(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                val fromPosition = viewHolder.adapterPosition
                val toPosition = target.adapterPosition
                swapSections(fromPosition, toPosition)
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                // No swipe actions needed
            }
        })

        itemTouchHelper.attachToRecyclerView(recyclerView)
    }

    // Save the order of sections to SharedPreferences
    private fun saveSectionsOrder() {
        val sharedPreferences: SharedPreferences = context.getSharedPreferences("study_tracker", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val sectionOrder = sections.joinToString(",") { it.name } // Use name as the unique identifier
        editor.putString("section_order", sectionOrder)
        editor.apply()
    }

    // Load sections in the saved order from SharedPreferences
    fun loadSectionsOrder() {
        val sharedPreferences: SharedPreferences = context.getSharedPreferences("study_tracker", Context.MODE_PRIVATE)
        val sectionOrderString = sharedPreferences.getString("section_order", null)

        if (sectionOrderString != null) {
            val sectionOrder = sectionOrderString.split(",")
            sections.sortBy { sectionOrder.indexOf(it.name) } // Use name to sort
            notifyDataSetChanged() // Notify the adapter that data has changed
        }
    }

    inner class SectionViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val sectionNameTextView: TextView = itemView.findViewById(R.id.section_name_text_view)

        fun bind(section: Section) {
            sectionNameTextView.text = section.name

            // OnTouchListener for initiating drag
            itemView.setOnTouchListener { v, event ->
                if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                    if (event.pointerCount == 1) { // Only for single touch
                        itemTouchHelper.startDrag(this) // Start drag
                    }
                }
                false
            }
        }
    }
}
